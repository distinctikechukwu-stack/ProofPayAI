import { CircleHelp, Settings2, ShieldCheck, Sparkles } from "lucide-react";
import { DemoNotice, PageHeading } from "../components/WorkspacePrimitives";

export function SettingsPage() {
  return <>
    <PageHeading eyebrow="ACCOUNT & INTEGRATIONS" title="Settings" description="Manage workspace details and connect the services that power ProofPay AI." />
    <DemoNotice>Account settings and provider connections are not active in this preview. Secrets must be configured on the server and must never be entered into browser forms.</DemoNotice>
    <section className="surface-card settings-section">
      <h2>Integration setup</h2>
      <p>Connection status will be read from server configuration after the project setup phase.</p>
      {[
        { name: "Supabase", detail: "Authentication, project records, and access controls", icon: Settings2 },
        { name: "AI provider", detail: "Structured milestone generation and scope review", icon: Sparkles },
        { name: "PayPal Sandbox", detail: "Invoicing API v2 and verified webhooks", icon: ShieldCheck },
      ].map(({ name, detail, icon: Icon }) => <div className="settings-integration-row" key={name}>
        <span className="settings-integration-icon"><Icon size={16} /></span>
        <span><strong>{name}</strong><small>{detail}</small></span>
        <span className="status-pill status-warning">Not connected</span>
      </div>)}
    </section>
    <div className="settings-help"><CircleHelp size={16} /><span>Read the setup guide in the project README for local configuration.</span></div>
  </>;
}
