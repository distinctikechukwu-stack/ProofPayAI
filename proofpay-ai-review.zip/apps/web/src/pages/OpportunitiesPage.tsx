import { useEffect, useMemo, useRef, useState } from "react";
import type { FormEvent } from "react";
import { ArrowLeft, ArrowUpRight, Bookmark, BriefcaseBusiness, Check, CircleAlert, Flag, Plus, Search, Send, X } from "lucide-react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { PageHeading, StatusPill } from "../components/WorkspacePrimitives";
import { useAuth } from "../contexts/AuthContext";
import { apiRequest } from "../lib/api";

type Job = {
  id: string; isOwner?: boolean; title: string; summary: string; description: string; requirements: string[]; skills: string[];
  category: string; experienceLevel: "entry" | "intermediate" | "expert"; projectType: "fixed" | "hourly";
  fixedBudgetMinor: string | null; hourlyRateMinMinor: string | null; hourlyRateMaxMinor: string | null; currency: string;
  estimatedDays: number | null; status: "draft" | "published" | "closed" | "archived"; isFavorite?: boolean; createdAt: string;
};
type Proposal = {
  id: string; jobId: string; isMine: boolean; coverLetter: string; quoteMinor: string; currency: string;
  timelineDays: number; portfolioItemIds: string[]; status: string; createdAt: string;
};
type Offer = {
  id: string; proposalId: string; jobId: string; isRecipient: boolean; terms: string;
  amountMinor: string; currency: string; timelineDays: number; status: string; projectId: string | null;
  createdAt: string; respondedAt: string | null;
};
type PortfolioRef = { id: string; title: string };
type JobDraft = {
  title: string; summary: string; description: string; requirements: string; skills: string; category: string;
  experienceLevel: Job["experienceLevel"]; projectType: Job["projectType"]; fixedBudget: string;
  hourlyMin: string; hourlyMax: string; currency: string; estimatedDays: string;
};

const emptyJobDraft = (): JobDraft => ({
  title: "", summary: "", description: "", requirements: "", skills: "", category: "",
  experienceLevel: "intermediate", projectType: "fixed", fixedBudget: "", hourlyMin: "", hourlyMax: "",
  currency: "USD", estimatedDays: "",
});
const splitLines = (value: string) => value.split(/\r?\n|,/).map((item) => item.trim()).filter(Boolean);
const currencyDigits = (currency: string) => {
  try { return new Intl.NumberFormat("en-US", { style: "currency", currency }).resolvedOptions().maximumFractionDigits ?? 2; }
  catch { return 2; }
};
function amountMinor(value: string, currency: string): number | null {
  const digits = currencyDigits(currency);
  const match = digits === 0 ? /^(\d+)$/.exec(value.trim()) : new RegExp(`^(\\d+)(?:\\.(\\d{1,${digits}}))?$`).exec(value.trim());
  if (!match?.[1]) return null;
  try {
    const amount = BigInt(match[1]) * 10n ** BigInt(digits) + BigInt((match[2] ?? "").padEnd(digits, "0") || "0");
    return amount > 0n && amount <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(amount) : null;
  } catch { return null; }
}
function displayMinor(value: string | null, currency: string): string {
  if (!value || !/^\d+$/.test(value)) return "Budget not specified";
  const digits = currencyDigits(currency);
  const minor = BigInt(value);
  const divisor = 10n ** BigInt(digits);
  const whole = minor / divisor;
  const fraction = digits ? `.${(minor % divisor).toString().padStart(digits, "0")}` : "";
  try { return `${new Intl.NumberFormat("en-US", { style: "currency", currency, maximumFractionDigits: 0 }).format(whole)}${fraction}`; }
  catch { return `${currency} ${whole}${fraction}`; }
}
function jobBudget(job: Job) {
  return job.projectType === "fixed"
    ? `${displayMinor(job.fixedBudgetMinor, job.currency)} fixed price`
    : `${displayMinor(job.hourlyRateMinMinor, job.currency)}–${displayMinor(job.hourlyRateMaxMinor, job.currency)} / hour`;
}

export function OpportunitiesPage() {
  const { jobId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [roles, setRoles] = useState<string[]>([]);
  const [portfolio, setPortfolio] = useState<PortfolioRef[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [projectType, setProjectType] = useState("");
  const [experience, setExperience] = useState("");
  const [skill, setSkill] = useState("");
  const [budgetMin, setBudgetMin] = useState("");
  const [budgetMax, setBudgetMax] = useState("");
  const [budgetCurrency, setBudgetCurrency] = useState("USD");
  const [sort, setSort] = useState("recent");
  const [savedOnly, setSavedOnly] = useState(false);
  const [showJobEditor, setShowJobEditor] = useState(false);
  const [editingJob, setEditingJob] = useState<Job | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const isFreelancer = roles.includes("freelancer");
  const isClient = roles.includes("client");

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    let active = true;
    setLoading(true); setError("");
    const work: Array<Promise<unknown>> = [
      apiRequest<{ roles: string[]; portfolio?: PortfolioRef[] }>("/api/profile").then((profile) => {
        if (active) { setRoles(profile.roles); setPortfolio(profile.portfolio ?? []); }
      }),
      apiRequest<{ offers: Offer[] }>("/api/offers").then((response) => { if (active) setOffers(response.offers); }),
    ];
    if (jobId) {
      work.push(apiRequest<{ job: Job }>(`/api/jobs/${encodeURIComponent(jobId)}`).then((response) => { if (active) setSelectedJob(response.job); }));
      work.push(apiRequest<{ proposals: Proposal[] }>(`/api/jobs/${encodeURIComponent(jobId)}/proposals`).then((response) => { if (active) setProposals(response.proposals); }));
    } else {
      work.push(apiRequest<{ jobs: Job[] }>("/api/jobs").then((response) => { if (active) setJobs(response.jobs); }));
      setSelectedJob(null); setProposals([]);
    }
    void Promise.all(work).catch((reason: unknown) => {
      if (active) setError(reason instanceof Error ? reason.message : "Marketplace records could not be loaded.");
    }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [jobId, refreshKey, user]);

  const filteredJobs = useMemo(() => jobs.filter((job) => {
    const searchText = `${job.title} ${job.summary} ${job.category} ${job.skills.join(" ")} ${job.requirements.join(" ")}`.toLocaleLowerCase();
    return (!search || searchText.includes(search.toLocaleLowerCase()))
      && (!category || job.category.toLocaleLowerCase() === category.toLocaleLowerCase())
      && (!projectType || job.projectType === projectType)
      && (!experience || job.experienceLevel === experience)
      && (!skill || job.skills.some((item) => item.toLocaleLowerCase().includes(skill.toLocaleLowerCase())))
      && (!budgetMin || job.currency === budgetCurrency && BigInt(job.fixedBudgetMinor ?? job.hourlyRateMaxMinor ?? "0") >= BigInt(amountMinor(budgetMin, budgetCurrency) ?? Number.MAX_SAFE_INTEGER))
      && (!budgetMax || job.currency === budgetCurrency && BigInt(job.fixedBudgetMinor ?? job.hourlyRateMinMinor ?? "0") <= BigInt(amountMinor(budgetMax, budgetCurrency) ?? -1))
      && (!savedOnly || job.isFavorite);
  }).sort((left, right) => {
    if (sort === "recent") return right.createdAt.localeCompare(left.createdAt);
    const leftAmount = BigInt(left.fixedBudgetMinor ?? left.hourlyRateMinMinor ?? "0");
    const rightAmount = BigInt(right.fixedBudgetMinor ?? right.hourlyRateMinMinor ?? "0");
    const result = leftAmount < rightAmount ? -1 : leftAmount > rightAmount ? 1 : 0;
    return sort === "budget_low" ? result : -result;
  }), [budgetCurrency, budgetMax, budgetMin, category, experience, jobs, projectType, savedOnly, search, skill, sort]);

  const refresh = () => setRefreshKey((current) => current + 1);
  const toggleFavorite = async (job: Job) => {
    if (!user) return;
    setError("");
    try {
      await apiRequest(`/api/jobs/${job.id}/favorite`, { method: "POST", body: { saved: !job.isFavorite } });
      setJobs((current) => current.map((item) => item.id === job.id ? { ...item, isFavorite: !item.isFavorite } : item));
      setSelectedJob((current) => current?.id === job.id ? { ...current, isFavorite: !current.isFavorite } : current);
    } catch (reason) { setError(reason instanceof Error ? reason.message : "The saved-job list could not be changed."); }
  };
  const changeJobStatus = async (job: Job, action: "publish" | "close" | "reopen" | "archive" | "delete") => {
    try {
      await apiRequest(`/api/jobs/${job.id}/status`, { method: "POST", body: { action } });
      setNotice(action === "delete" ? "Draft job deleted." : `Job ${action === "publish" ? "published" : action === "reopen" ? "reopened" : action + "d"}.`);
      if (action === "delete") navigate("/app/opportunities");
      refresh();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "The job status could not be changed."); }
  };
  const saveJob = async (draft: JobDraft, idempotencyKey: string) => {
    const fixed = draft.projectType === "fixed" ? amountMinor(draft.fixedBudget, draft.currency) : null;
    const hourlyMin = draft.projectType === "hourly" ? amountMinor(draft.hourlyMin, draft.currency) : null;
    const hourlyMax = draft.projectType === "hourly" ? amountMinor(draft.hourlyMax, draft.currency) : null;
    if ((draft.projectType === "fixed" && fixed === null) || (draft.projectType === "hourly" && (hourlyMin === null || hourlyMax === null || hourlyMin > hourlyMax))) {
      throw new Error("Enter a valid exact budget or hourly rate range.");
    }
    const result = await apiRequest<{ jobId: string }>("/api/jobs", { method: "POST", body: {
      id: editingJob?.id ?? null, idempotencyKey, title: draft.title, summary: draft.summary, description: draft.description,
      requirements: splitLines(draft.requirements), skills: splitLines(draft.skills), category: draft.category,
      experienceLevel: draft.experienceLevel, projectType: draft.projectType, fixedBudgetMinor: fixed,
      hourlyRateMinMinor: hourlyMin, hourlyRateMaxMinor: hourlyMax, currency: draft.currency,
      estimatedDays: draft.estimatedDays.trim() ? Number(draft.estimatedDays) : null,
    } });
    setNotice("Job draft saved. Publish it when the listing is ready for applicants.");
    setShowJobEditor(false); setEditingJob(null); refresh();
    return result;
  };

  const updateProposal = async (proposalId: string, action: "submit" | "withdraw" | "shortlist" | "reject" | "invite_interview"): Promise<boolean> => {
    try {
      await apiRequest(`/api/proposals/${proposalId}/transition`, { method: "POST", body: { action } });
      setNotice(action === "invite_interview" ? "Interview status recorded. No notification was sent because messaging is not available yet." : `Proposal ${action === "submit" ? "submitted" : action === "withdraw" ? "withdrawn" : action === "shortlist" ? "shortlisted" : "rejected"}.`);
      refresh();
      return true;
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Proposal status could not be changed."); return false; }
  };

  const submitOffer = async (proposal: Proposal, input: { terms: string; amount: string; timeline: string; key: string }) => {
    const amount = amountMinor(input.amount, selectedJob?.currency ?? proposal.currency);
    if (amount === null || !Number.isSafeInteger(Number(input.timeline)) || Number(input.timeline) < 1) throw new Error("Enter a positive exact offer amount and delivery timeline.");
    await apiRequest(`/api/proposals/${proposal.id}/offers`, { method: "POST", body: {
      idempotencyKey: input.key, terms: input.terms, amountMinor: amount,
      currency: selectedJob?.currency ?? proposal.currency, timelineDays: Number(input.timeline),
    } });
    setNotice("Offer sent. The freelancer must explicitly accept or decline it.");
    refresh();
  };

  const respondOffer = async (offer: Offer, decision: "accept" | "decline") => {
    try {
      const response = await apiRequest<{ status: string; projectId?: string | null; contractType?: "fixed" | "hourly" | null }>(`/api/offers/${offer.id}/respond`, { method: "POST", body: { decision } });
      if (response.projectId) {
        setNotice(response.contractType === "hourly"
          ? "Hourly offer accepted. The rate agreement is ready for both parties to review; time tracking unlocks after dual approval."
          : "Offer accepted. A draft project and agreement were created; both parties still need to review and approve the terms.");
        navigate(`/app/projects/${response.projectId}`);
      } else setNotice("Offer declined.");
      refresh();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "The offer response could not be saved."); }
  };

  if (!user) return <>
    <PageHeading eyebrow="FREELANCE MARKETPLACE" title="Opportunities" description="Explore fixed-price and hourly work, apply with a scoped proposal, and keep hiring decisions attached to the agreement." />
    <div className="marketplace-empty"><BriefcaseBusiness size={24} /><h2>Sign in to browse persisted jobs</h2><p>Sample workspace records are not presented as live marketplace listings.</p><Link className="button-primary" to="/signin">Sign in <ArrowUpRight size={14} /></Link></div>
  </>;

  return <>
    <PageHeading eyebrow="FREELANCE MARKETPLACE" title={jobId ? "Opportunity details" : "Find your next opportunity"} description="Browse persisted listings, compare terms, and keep proposals and offer decisions attached to the job." action={!jobId && isClient ? <button className="button-primary" type="button" onClick={() => { setEditingJob(null); setShowJobEditor((open) => !open); }}><Plus size={15} /> Post a job</button> : undefined} />
    {error && <p className="marketplace-alert" role="alert"><CircleAlert size={15} />{error}</p>}
    {notice && <p className="marketplace-notice" role="status"><Check size={15} />{notice}</p>}
    {showJobEditor && <JobEditor initial={editingJob} onCancel={() => { setShowJobEditor(false); setEditingJob(null); }} onSave={saveJob} />}
    {jobId ? <>
      <Link className="marketplace-back" to="/app/opportunities"><ArrowLeft size={14} /> Back to opportunities</Link>
      {loading ? <div className="marketplace-empty" role="status">Loading job details…</div> : selectedJob ? <JobDetail
        job={selectedJob} isClient={isClient} isFreelancer={isFreelancer} proposals={proposals} offers={offers.filter((offer) => offer.jobId === selectedJob.id)} portfolio={portfolio}
        onFavorite={() => void toggleFavorite(selectedJob)} onChangeStatus={(action) => void changeJobStatus(selectedJob, action)}
        onProposal={async (body, submit) => {
          const result = await apiRequest<{ proposalId: string }>(`/api/jobs/${selectedJob.id}/proposals`, { method: "POST", body });
          if (submit && !(await updateProposal(result.proposalId, "submit"))) throw new Error("Your draft was saved, but the proposal was not submitted. Review the message and retry.");
          else { setNotice("Proposal draft saved to your account."); refresh(); }
        }}
        onTransition={(proposalId, action) => void updateProposal(proposalId, action)}
        onOffer={submitOffer}
        onRespondOffer={respondOffer}
        onReport={async (reason, details) => {
          await apiRequest(`/api/jobs/${selectedJob.id}/reports`, { method: "POST", body: { reason, details } });
          setNotice("Report sent for review. It is private to you and marketplace administrators.");
        }}
        onEdit={() => { setEditingJob(selectedJob); setShowJobEditor(true); }}
      /> : <div className="marketplace-empty"><h2>Job not found</h2><p>This listing may be private, closed, or unavailable to your account.</p><Link to="/app/opportunities">Browse open jobs</Link></div>}
    </> : <>
      {isClient && <div className="marketplace-role-note"><strong>Client account</strong><span>Post and manage a job listing. Review applicants and send offers from the job details.</span></div>}
      <section className="marketplace-toolbar">
        <label className="marketplace-search"><Search size={16} /><input aria-label="Search jobs" placeholder="Search roles, skills, or requirements" value={search} onChange={(event) => setSearch(event.target.value)} /></label>
        <select aria-label="Category filter" value={category} onChange={(event) => setCategory(event.target.value)}><option value="">All categories</option>{[...new Set(jobs.map((job) => job.category))].sort().map((item) => <option key={item}>{item}</option>)}</select>
        <select aria-label="Project type filter" value={projectType} onChange={(event) => setProjectType(event.target.value)}><option value="">Fixed or hourly</option><option value="fixed">Fixed price</option><option value="hourly">Hourly</option></select>
        <select aria-label="Experience filter" value={experience} onChange={(event) => setExperience(event.target.value)}><option value="">Any experience</option><option value="entry">Entry level</option><option value="intermediate">Intermediate</option><option value="expert">Expert</option></select>
        <input aria-label="Skill filter" value={skill} onChange={(event) => setSkill(event.target.value)} placeholder="Skill" />
        <label className="marketplace-budget-filter"><span>Budget range ({budgetCurrency})</span><input aria-label="Minimum budget" inputMode="decimal" value={budgetMin} onChange={(event) => setBudgetMin(event.target.value)} placeholder="Min" /><input aria-label="Maximum budget" inputMode="decimal" value={budgetMax} onChange={(event) => setBudgetMax(event.target.value)} placeholder="Max" /><input aria-label="Budget currency" maxLength={3} pattern="[A-Z]{3}" value={budgetCurrency} onChange={(event) => setBudgetCurrency(event.target.value.toUpperCase())} /></label>
        <select aria-label="Sort jobs" value={sort} onChange={(event) => setSort(event.target.value)}><option value="recent">Most recent</option><option value="budget_low">Budget: low to high</option><option value="budget_high">Budget: high to low</option></select>
        {isFreelancer && <button className={`marketplace-filter-chip${savedOnly ? " selected" : ""}`} type="button" aria-pressed={savedOnly} onClick={() => setSavedOnly(!savedOnly)}><Bookmark size={13} /> Saved jobs</button>}
      </section>
      {loading ? <div className="marketplace-empty" role="status">Loading marketplace listings…</div> : filteredJobs.length ? <div className="marketplace-job-list">{filteredJobs.map((job) => <article className="marketplace-job-card" key={job.id}>
        <div className="marketplace-job-top"><div><span className="marketplace-category">{job.category} · {job.experienceLevel}</span><h2><Link to={`/app/opportunities/${job.id}`}>{job.title}<ArrowUpRight size={14} /></Link></h2><p>{job.summary}</p></div><strong className="marketplace-budget">{jobBudget(job)}</strong></div>
        <div className="marketplace-job-tags">{job.skills.slice(0, 5).map((skill) => <span key={skill}>{skill}</span>)}</div>
        <div className="marketplace-job-bottom"><span>{job.status === "published" ? "Open for proposals" : job.status.replaceAll("_", " ")} · {job.estimatedDays ? `${job.estimatedDays} day estimate` : "Timeline to discuss"}</span><div>{isFreelancer && job.status === "published" && <button className={`marketplace-icon-action${job.isFavorite ? " saved" : ""}`} type="button" aria-label={job.isFavorite ? "Remove saved job" : "Save job"} onClick={() => void toggleFavorite(job)}><Bookmark size={15} fill={job.isFavorite ? "currentColor" : "none"} /></button>}<Link className="marketplace-open-link" to={`/app/opportunities/${job.id}`}>View details <ArrowUpRight size={13} /></Link></div></div>
      </article>)}</div> : <div className="marketplace-empty"><Search size={22} /><h2>{jobs.length ? "No matching jobs" : "No marketplace jobs yet"}</h2><p>{jobs.length ? "Adjust a filter to look at more listings." : isClient ? "Post a draft listing, review its details, then publish it for applicants." : "Published opportunities will appear here when clients post jobs."}</p>{jobs.length > 0 && <button className="button-secondary" type="button" onClick={() => { setSearch(""); setCategory(""); setProjectType(""); setExperience(""); setSkill(""); setBudgetMin(""); setBudgetMax(""); setSavedOnly(false); }}>Clear filters</button>}</div>}
      {offers.length > 0 && <section className="marketplace-offers-panel"><div className="marketplace-section-heading"><div><span className="eyebrow">YOUR INBOX</span><h2>Offers</h2></div><span>{offers.filter((offer) => offer.isRecipient && offer.status === "sent").length} awaiting your response</span></div>{offers.map((offer) => <OfferRow key={offer.id} offer={offer} onRespond={respondOffer} />)}</section>}
    </>}
  </>;
}

function JobEditor({ initial, onCancel, onSave }: { initial: Job | null; onCancel: () => void; onSave: (draft: JobDraft, key: string) => Promise<unknown> }) {
  const [draft, setDraft] = useState<JobDraft>(() => initial ? {
    title: initial.title, summary: initial.summary, description: initial.description, requirements: initial.requirements.join("\n"),
    skills: initial.skills.join(", "), category: initial.category, experienceLevel: initial.experienceLevel, projectType: initial.projectType,
    fixedBudget: initial.fixedBudgetMinor ? minorToText(initial.fixedBudgetMinor, initial.currency) : "",
    hourlyMin: initial.hourlyRateMinMinor ? minorToText(initial.hourlyRateMinMinor, initial.currency) : "",
    hourlyMax: initial.hourlyRateMaxMinor ? minorToText(initial.hourlyRateMaxMinor, initial.currency) : "",
    currency: initial.currency, estimatedDays: initial.estimatedDays ? String(initial.estimatedDays) : "",
  } : emptyJobDraft());
  const [key] = useState(() => crypto.randomUUID());
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const change = (field: keyof JobDraft, value: string) => setDraft((current) => ({ ...current, [field]: value }));
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setBusy(true); setMessage("");
    try { await onSave(draft, key); }
    catch (reason) { setMessage(reason instanceof Error ? reason.message : "The job draft could not be saved."); }
    finally { setBusy(false); }
  };
  return <section className="surface-card marketplace-editor">
    <div className="marketplace-editor-heading"><div><span className="eyebrow">CLIENT JOB POST</span><h2>{initial ? "Edit listing" : "Describe the work clearly"}</h2><p>Job listings are editable drafts until you publish them.</p></div><button className="marketplace-icon-action" type="button" aria-label="Close job form" onClick={onCancel}><X size={15} /></button></div>
    <form className="marketplace-form" onSubmit={submit}>
      <label>Job title<input required minLength={5} maxLength={160} value={draft.title} onChange={(event) => change("title", event.target.value)} placeholder="e.g. Build an appointment scheduling website" /></label>
      <label>Short summary<input required minLength={10} maxLength={240} value={draft.summary} onChange={(event) => change("summary", event.target.value)} /></label>
      <label>Full description<textarea required minLength={30} maxLength={8000} rows={5} value={draft.description} onChange={(event) => change("description", event.target.value)} /></label>
      <div className="marketplace-form-grid"><label>Category<input required minLength={2} maxLength={80} value={draft.category} onChange={(event) => change("category", event.target.value)} placeholder="Development & technology" /></label><label>Experience<select value={draft.experienceLevel} onChange={(event) => change("experienceLevel", event.target.value)}><option value="entry">Entry level</option><option value="intermediate">Intermediate</option><option value="expert">Expert</option></select></label></div>
      <label>Requirements <span className="field-hint">One per line</span><textarea required rows={3} value={draft.requirements} onChange={(event) => change("requirements", event.target.value)} placeholder="Responsive layout\nAccessible keyboard navigation" /></label>
      <div className="marketplace-form-grid"><label>Skills <span className="field-hint">Comma separated</span><input value={draft.skills} onChange={(event) => change("skills", event.target.value)} placeholder="React, TypeScript" /></label><label>Project type<select value={draft.projectType} onChange={(event) => change("projectType", event.target.value)}><option value="fixed">Fixed price</option><option value="hourly">Hourly</option></select></label></div>
      {draft.projectType === "fixed" ? <label>Fixed budget ({draft.currency})<input required inputMode="decimal" placeholder="600.00" value={draft.fixedBudget} onChange={(event) => change("fixedBudget", event.target.value)} /></label> : <div className="marketplace-form-grid"><label>Minimum hourly rate ({draft.currency})<input required inputMode="decimal" value={draft.hourlyMin} onChange={(event) => change("hourlyMin", event.target.value)} /></label><label>Maximum hourly rate ({draft.currency})<input required inputMode="decimal" value={draft.hourlyMax} onChange={(event) => change("hourlyMax", event.target.value)} /></label></div>}
      <div className="marketplace-form-grid"><label>Currency<input required maxLength={3} pattern="[A-Z]{3}" value={draft.currency} onChange={(event) => change("currency", event.target.value.toUpperCase())} /></label><label>Estimated duration in days<input type="number" min="1" max="3650" value={draft.estimatedDays} onChange={(event) => change("estimatedDays", event.target.value)} placeholder="Optional" /></label></div>
      {message && <p className="marketplace-inline-error" role="alert">{message}</p>}
      <div className="marketplace-form-actions"><button className="button-secondary" type="button" onClick={onCancel}>Cancel</button><button className="button-primary" disabled={busy}>{busy ? "Saving…" : initial ? "Save changes" : "Save job draft"} <Check size={14} /></button></div>
    </form>
  </section>;
}

function minorToText(value: string, currency: string) {
  if (!/^\d+$/.test(value)) return "";
  const digits = currencyDigits(currency); const divisor = 10n ** BigInt(digits); const minor = BigInt(value);
  return digits ? `${minor / divisor}.${(minor % divisor).toString().padStart(digits, "0")}` : `${minor}`;
}

function JobDetail({
  job, isClient, isFreelancer, proposals, offers, portfolio, onFavorite, onChangeStatus, onProposal, onTransition, onOffer, onRespondOffer, onReport, onEdit,
}: {
  job: Job; isClient: boolean; isFreelancer: boolean; proposals: Proposal[]; offers: Offer[]; portfolio: PortfolioRef[];
  onFavorite: () => void; onChangeStatus: (action: "publish" | "close" | "reopen" | "archive" | "delete") => void;
  onProposal: (body: unknown, submit: boolean) => Promise<void>;
  onTransition: (proposalId: string, action: "submit" | "withdraw" | "shortlist" | "reject" | "invite_interview") => void;
  onOffer: (proposal: Proposal, input: { terms: string; amount: string; timeline: string; key: string }) => Promise<void>;
  onRespondOffer: (offer: Offer, decision: "accept" | "decline") => void;
  onReport: (reason: string, details: string) => Promise<void>; onEdit: () => void;
}) {
  const owner = job.isOwner === true;
  const ownProposal = proposals.find((proposal) => proposal.isMine);
  const [coverLetter, setCoverLetter] = useState(ownProposal?.coverLetter ?? "");
  const [quote, setQuote] = useState(ownProposal ? minorToText(ownProposal.quoteMinor, job.currency) : "");
  const [timeline, setTimeline] = useState(ownProposal ? String(ownProposal.timelineDays) : "14");
  const [selectedPortfolio, setSelectedPortfolio] = useState<string[]>(ownProposal?.portfolioItemIds ?? []);
  const [message, setMessage] = useState("");
  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState("suspicious");
  const [reportDetails, setReportDetails] = useState("");
  const [offerForm, setOfferForm] = useState<Record<string, { terms: string; amount: string; timeline: string; key: string }>>({});
  const offerKeys = useRef(new Map<string, string>());
  const relevantOffers = offers;
  const canEditProposal = job.status === "published" && (!ownProposal || ownProposal.status === "draft");
  const showProposal = !owner && isFreelancer && (job.status === "published" || Boolean(ownProposal));
  useEffect(() => {
    if (!ownProposal) return;
    setCoverLetter(ownProposal.coverLetter);
    setQuote(minorToText(ownProposal.quoteMinor, job.currency));
    setTimeline(String(ownProposal.timelineDays));
    setSelectedPortfolio(ownProposal.portfolioItemIds);
  }, [job.currency, ownProposal?.id, ownProposal?.coverLetter, ownProposal?.quoteMinor, ownProposal?.timelineDays, ownProposal?.portfolioItemIds]);
  const changePortfolio = (id: string, checked: boolean) => setSelectedPortfolio((current) => checked ? [...new Set([...current, id])] : current.filter((item) => item !== id));
  const saveProposal = async (submit: boolean) => {
    setMessage("");
    try {
      await onProposal({ coverLetter, quoteMinor: amountMinor(quote, job.currency), timelineDays: Number(timeline), portfolioItemIds: selectedPortfolio }, submit);
      setMessage(submit ? "Proposal submitted to the client." : "Proposal draft saved.");
    } catch (reason) { setMessage(reason instanceof Error ? reason.message : "Proposal could not be saved."); }
  };
  const initialOffer = (proposal: Proposal) => {
    const existing = offerForm[proposal.id];
    if (existing) return existing;
    let key = offerKeys.current.get(proposal.id);
    if (!key) { key = crypto.randomUUID(); offerKeys.current.set(proposal.id, key); }
    return { terms: "", amount: minorToText(proposal.quoteMinor, proposal.currency), timeline: String(proposal.timelineDays), key };
  };
  const patchOffer = (proposal: Proposal, field: "terms" | "amount" | "timeline", value: string) => setOfferForm((current) => ({
    ...current, [proposal.id]: { ...initialOffer(proposal), [field]: value },
  }));
  return <>
    <article className="marketplace-detail-card">
      <div className="marketplace-detail-top"><div><span className="marketplace-category">{job.category} · {job.experienceLevel}</span><h1>{job.title}</h1><p>{job.summary}</p></div><strong className="marketplace-budget">{jobBudget(job)}</strong></div>
      <div className="marketplace-detail-meta"><StatusPill status={job.status} /><span>{job.estimatedDays ? `Estimated ${job.estimatedDays} days` : "Timeline to discuss"}</span><span>Posted {new Date(job.createdAt).toLocaleDateString()}</span>{job.status === "published" && isFreelancer && <button type="button" className={`marketplace-outline-action${job.isFavorite ? " selected" : ""}`} onClick={onFavorite}><Bookmark size={14} />{job.isFavorite ? "Saved" : "Save job"}</button>}</div>
      {owner && isClient && <div className="marketplace-owner-actions">{job.status === "draft" && <><button type="button" className="button-secondary" onClick={onEdit}>Edit draft</button><button type="button" className="button-primary" onClick={() => onChangeStatus("publish")}>Publish job <ArrowUpRight size={14} /></button><button type="button" className="marketplace-text-action" onClick={() => { if (window.confirm("Delete this draft listing? This action cannot be undone.")) onChangeStatus("delete"); }}>Delete draft</button></>}{job.status === "published" && <button type="button" className="button-secondary" onClick={() => onChangeStatus("close")}>Close applications</button>}{job.status === "closed" && <><button type="button" className="button-secondary" onClick={() => onChangeStatus("reopen")}>Reopen job</button><button type="button" className="button-secondary" onClick={() => onChangeStatus("archive")}>Archive</button></>}</div>}
      <div className="marketplace-detail-section"><h2>About this project</h2><p>{job.description}</p></div>
      {job.requirements.length > 0 && <div className="marketplace-detail-section"><h2>Requirements</h2><ul>{job.requirements.map((requirement) => <li key={requirement}>{requirement}</li>)}</ul></div>}
      {job.skills.length > 0 && <div className="marketplace-detail-section"><h2>Skills</h2><div className="marketplace-job-tags">{job.skills.map((skill) => <span key={skill}>{skill}</span>)}</div></div>}
      {showProposal && <section className="marketplace-proposal-box"><div className="marketplace-section-heading"><div><span className="eyebrow">YOUR APPLICATION</span><h2>{canEditProposal ? ownProposal ? "Update your proposal" : "Send a thoughtful proposal" : "Application record"}</h2></div>{ownProposal && <StatusPill status={ownProposal.status} />}</div>
        {canEditProposal ? <form className="marketplace-form" onSubmit={(event) => { event.preventDefault(); void saveProposal(false); }}>
          <label>Cover letter<textarea required minLength={30} maxLength={5000} rows={5} value={coverLetter} onChange={(event) => setCoverLetter(event.target.value)} placeholder="Explain how you would approach the requirements and what you would deliver." /></label>
          <div className="marketplace-form-grid"><label>Your quote ({job.currency})<input required inputMode="decimal" value={quote} onChange={(event) => setQuote(event.target.value)} /></label><label>Expected timeline (days)<input required type="number" min="1" max="3650" value={timeline} onChange={(event) => setTimeline(event.target.value)} /></label></div>
          {portfolio.length > 0 && <fieldset className="marketplace-reference-list"><legend>Portfolio references <span className="field-hint">Choose only work you may share</span></legend>{portfolio.map((item) => <label key={item.id}><input type="checkbox" checked={selectedPortfolio.includes(item.id)} onChange={(event) => changePortfolio(item.id, event.target.checked)} /> {item.title}</label>)}</fieldset>}
          {ownProposal?.status === "draft" ? <div className="marketplace-form-actions"><button className="button-secondary" type="submit">Save draft</button><button className="button-primary" type="button" onClick={() => void saveProposal(true)}><Send size={14} /> Submit proposal</button></div> : <div className="marketplace-form-actions"><button className="button-secondary" type="submit">Save proposal draft</button><button className="button-primary" type="button" onClick={() => void saveProposal(true)}><Send size={14} /> Save & submit</button></div>}
          {message && <p role="status" className="marketplace-inline-note">{message}</p>}
        </form> : <div className="marketplace-submitted-proposal"><p>{ownProposal?.coverLetter ?? "Your draft is saved, but this job is no longer open for new proposals."}</p>{ownProposal && <div className="marketplace-detail-meta"><strong>{displayMinor(ownProposal.quoteMinor, ownProposal.currency)}</strong><span>{ownProposal.timelineDays} day estimate</span><span>{ownProposal.portfolioItemIds.length} portfolio reference(s)</span></div>}{ownProposal && ["submitted", "shortlisted", "interview_invited"].includes(ownProposal.status) && <button className="marketplace-text-action" type="button" onClick={() => onTransition(ownProposal.id, "withdraw")}>Withdraw proposal</button>}{ownProposal?.status === "withdrawn" && <p className="marketplace-inline-note">This application was withdrawn. The one-application-per-job rule prevents a duplicate application.</p>}</div>}
      </section>}
      {owner && <section className="marketplace-proposal-box"><div className="marketplace-section-heading"><div><span className="eyebrow">APPLICANTS</span><h2>Proposal review</h2></div><span>{proposals.length} applicant{proposals.length === 1 ? "" : "s"}</span></div>{proposals.length ? <div className="marketplace-applicant-list">{proposals.map((proposal) => <article className="marketplace-applicant-card" key={proposal.id}>
        <div className="marketplace-applicant-top"><span className="marketplace-avatar-small" aria-hidden="true">F</span><div><strong>Freelancer applicant</strong><small>{displayMinor(proposal.quoteMinor, proposal.currency)} · {proposal.timelineDays} days</small></div><StatusPill status={proposal.status} /></div>
        <p>{proposal.coverLetter}</p>
        {proposal.portfolioItemIds.length > 0 && <span className="marketplace-inline-note">{proposal.portfolioItemIds.length} portfolio reference(s) attached.</span>}
        {isClient && ["submitted", "shortlisted", "interview_invited"].includes(proposal.status) && <div className="marketplace-form-actions"><button className="button-secondary" type="button" onClick={() => onTransition(proposal.id, "shortlist")}>Shortlist</button><button className="button-secondary" type="button" onClick={() => onTransition(proposal.id, "invite_interview")}>Mark interview requested</button><button className="marketplace-text-action" type="button" onClick={() => onTransition(proposal.id, "reject")}>Reject</button></div>}
        {isClient && ["submitted", "shortlisted", "interview_invited"].includes(proposal.status) && <OfferComposer value={initialOffer(proposal)} onChange={(field, value) => patchOffer(proposal, field, value)} onSubmit={() => void onOffer(proposal, initialOffer(proposal)).catch((reason: unknown) => setMessage(reason instanceof Error ? reason.message : "Offer could not be sent."))} />}
      </article>)}</div> : <p className="marketplace-empty-inline">No proposals are available for this job.</p>}</section>}
      {!owner && isFreelancer && job.status === "published" && <button className="marketplace-text-action marketplace-report-toggle" type="button" onClick={() => setReportOpen(!reportOpen)}><Flag size={13} /> Report a suspicious listing</button>}
      {reportOpen && <form className="marketplace-report-form" onSubmit={(event) => { event.preventDefault(); void onReport(reportReason, reportDetails).then(() => { setReportOpen(false); setMessage("Thank you. The report was recorded for administrator review."); }).catch((reason: unknown) => setMessage(reason instanceof Error ? reason.message : "The report could not be sent.")); }}><label>Reason<select value={reportReason} onChange={(event) => setReportReason(event.target.value)}><option value="suspicious">Suspicious activity</option><option value="misleading">Misleading listing</option><option value="prohibited">Prohibited work</option><option value="other">Other</option></select></label><label>Details<textarea maxLength={2000} rows={3} value={reportDetails} onChange={(event) => setReportDetails(event.target.value)} /></label><button className="button-secondary">Send private report</button>{message && <span role="status">{message}</span>}</form>}
    </article>
    {relevantOffers.length > 0 && <section className="marketplace-offers-panel"><div className="marketplace-section-heading"><div><span className="eyebrow">JOB OFFERS</span><h2>Offer decisions</h2></div></div>{relevantOffers.map((offer) => <OfferRow key={offer.id} offer={offer} onRespond={onRespondOffer} />)}</section>}
  </>;
}

function OfferComposer({ value, onChange, onSubmit }: { value: { terms: string; amount: string; timeline: string; key: string }; onChange: (field: "terms" | "amount" | "timeline", value: string) => void; onSubmit: () => void }) {
  return <div className="marketplace-offer-composer"><strong>Send an offer</strong><label>Offer terms<textarea required minLength={20} maxLength={5000} rows={3} value={value.terms} onChange={(event) => onChange("terms", event.target.value)} placeholder="Clarify the deliverables, responsibilities, and review steps." /></label><div className="marketplace-form-grid"><label>Offer amount<input required inputMode="decimal" value={value.amount} onChange={(event) => onChange("amount", event.target.value)} /></label><label>Timeline in days<input required type="number" min="1" max="3650" value={value.timeline} onChange={(event) => onChange("timeline", event.target.value)} /></label></div><button type="button" className="button-primary" onClick={onSubmit}>Send offer <Send size={13} /></button></div>;
}

function OfferRow({ offer, onRespond }: { offer: Offer; onRespond: (offer: Offer, decision: "accept" | "decline") => void }) {
  const isRecipient = offer.isRecipient;
  return <article className="marketplace-offer-row"><div><strong>{isRecipient ? "Offer received" : "Offer sent"}</strong><span>{displayMinor(offer.amountMinor, offer.currency)} · {offer.timelineDays} days · {offer.status}</span><p>{offer.terms}</p>{offer.projectId && <Link to={`/app/projects/${offer.projectId}`}>Open draft workspace <ArrowUpRight size={13} /></Link>}</div>{isRecipient && offer.status === "sent" && <div className="marketplace-form-actions"><button type="button" className="button-secondary" onClick={() => onRespond(offer, "decline")}>Decline</button><button type="button" className="button-primary" onClick={() => onRespond(offer, "accept")}>Accept offer <Check size={13} /></button></div>}</article>;
}
