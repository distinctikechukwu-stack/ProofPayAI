export interface PayableMilestone {
  projectId: string;
  projectTitle: string;
  clientName: string;
  milestoneId: string;
  milestoneTitle: string;
  amountMinor: string;
  currency: string;
  dueDate: string | null;
  invoiceId: string | null;
  invoiceStatus: string | null;
}

export interface InvoiceRecord {
  id: string;
  projectId: string;
  projectTitle: string;
  milestoneId: string;
  invoiceNumber: string;
  invoiceUrl: string | null;
  status: string;
  providerStatus: string | null;
  amountMinor: string;
  currency: string;
  dueDate: string | null;
  paidAt: string | null;
  createdAt: string | null;
  updatedAt: string | null;
}

export interface InvoicesResponse {
  invoices: InvoiceRecord[];
  candidates: PayableMilestone[];
  integrations: {
    paypalSandbox: boolean;
    webhook: boolean;
    invoiceOperations: boolean;
  };
}
